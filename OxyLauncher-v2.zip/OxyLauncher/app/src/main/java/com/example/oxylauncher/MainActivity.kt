package com.example.oxylauncher

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.DragEvent
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.hypot

data class AppInfo(
    val key: String,
    val pkg: String,
    val label: String,
    val icon: Drawable,
    val launchIntent: Intent,
    val isSystem: Boolean
)

/** from: "home", "dock" или "drawer" */
class DragInfo(val key: String, val from: String, val fromCell: Int)

class MenuItem(val title: String, val action: () -> Unit)

class MainActivity : AppCompatActivity() {

    private val allApps = mutableListOf<AppInfo>()
    private val byKey = HashMap<String, AppInfo>()
    private val home = HashMap<Int, String>()
    private val dock = HashMap<Int, String>()
    private lateinit var prefs: SharedPreferences

    private lateinit var homeGrid: CellGrid
    private lateinit var dockGrid: CellGrid
    private lateinit var hint: TextView
    private lateinit var drawer: View
    private lateinit var drawerList: RecyclerView
    private lateinit var search: EditText
    private lateinit var dragBar: View
    private lateinit var editBar: View
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var gestures: GestureDetector

    private var drawerOpen = false
    private var editMode = false
    private var menu: PopupWindow? = null
    private var touchSlop = 0

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            reloadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("layout", MODE_PRIVATE)
        touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        homeGrid = findViewById(R.id.homeGrid)
        dockGrid = findViewById(R.id.dockGrid)
        homeGrid.cols = 4
        homeGrid.rows = 5
        dockGrid.cols = 4
        dockGrid.rows = 1
        hint = findViewById(R.id.hint)
        drawer = findViewById(R.id.drawer)
        drawerList = findViewById(R.id.appGrid)
        search = findViewById(R.id.search)
        dragBar = findViewById(R.id.dragBar)
        editBar = findViewById(R.id.editBar)
        drawer.isClickable = true

        drawerAdapter = AppAdapter { v, app -> attachBehavior(v, app, "drawer", -1) }
        drawerList.layoutManager = GridLayoutManager(this, 4)
        drawerList.adapter = drawerAdapter
        search.doAfterTextChanged { text -> filter(text?.toString().orEmpty()) }

        homeGrid.setOnDragListener(gridDragListener(homeGrid, home))
        dockGrid.setOnDragListener(gridDragListener(dockGrid, dock))
        homeGrid.setOnLongClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            setEdit(true)
            true
        }

        findViewById<View>(R.id.removeZone).setOnDragListener(zoneListener { info ->
            mapFor(info.from)?.remove(info.fromCell)
        })
        findViewById<View>(R.id.uninstallZone).setOnDragListener(zoneListener { info ->
            byKey[info.key]?.let { uninstall(it) }
        })
        findViewById<View>(R.id.root).setOnDragListener { _, e ->
            when (e.action) {
                DragEvent.ACTION_DRAG_STARTED -> {
                    dragBar.visibility = View.VISIBLE
                    true
                }
                DragEvent.ACTION_DRAG_ENDED -> {
                    dragBar.visibility = View.GONE
                    saveAndRender()
                    true
                }
                else -> true
            }
        }

        findViewById<View>(R.id.btnWallpaper).setOnClickListener {
            try {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Обои"))
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(this, "Не удалось открыть выбор обоев", Toast.LENGTH_SHORT).show()
            }
        }
        findViewById<View>(R.id.btnDone).setOnClickListener { setEdit(false) }

        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(
                e1: MotionEvent?,
                e2: MotionEvent,
                velocityX: Float,
                velocityY: Float
            ): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (abs(dy) < abs(dx)) return false
                if (!drawerOpen && dy < -dp(80) && velocityY < -800) {
                    openDrawer()
                    return true
                }
                if (drawerOpen && dy > dp(80) && velocityY > 800 &&
                    !drawerList.canScrollVertically(-1)
                ) {
                    closeDrawer()
                    return true
                }
                return false
            }
        })

        reloadApps()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, filter, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: IllegalArgumentException) {
            // уже снят
        }
        dismissMenu()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) {
            dismissMenu()
            if (drawerOpen) closeDrawer()
            setEdit(false)
        }
    }

    override fun onBackPressed() {
        when {
            menu != null -> dismissMenu()
            drawerOpen -> closeDrawer()
            editMode -> setEdit(false)
            else -> { /* лаунчер: назад ничего не закрывает */ }
        }
    }

    // ---------- данные ----------

    private fun reloadApps() {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(query, 0)

        allApps.clear()
        byKey.clear()
        for (ri in resolved) {
            val pkg = ri.activityInfo.packageName
            if (pkg == packageName) continue
            val cls = ri.activityInfo.name
            val intent = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(pkg, cls)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val system = (ri.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val app = AppInfo("$pkg/$cls", pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm), intent, system)
            allApps.add(app)
            byKey[app.key] = app
        }
        allApps.sortBy { it.label.lowercase() }

        loadLayout()
        if (allApps.isNotEmpty()) {
            if (!prefs.getBoolean("init", false)) {
                buildDefaultDock()
                prefs.edit().putBoolean("init", true).apply()
            }
            home.entries.removeAll { !byKey.containsKey(it.value) }
            dock.entries.removeAll { !byKey.containsKey(it.value) }
            saveLayout()
        }
        filter(search.text?.toString().orEmpty())
        render()
    }

    private fun buildDefaultDock() {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        var cell = 0
        for (i in intents) {
            val pkg = packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName ?: continue
            val app = allApps.firstOrNull { a -> a.pkg == pkg } ?: continue
            if (dock.values.contains(app.key)) continue
            dock[cell] = app.key
            cell++
        }
    }

    private fun loadLayout() {
        home.clear()
        dock.clear()
        parse(prefs.getString("home", "") ?: "", home)
        parse(prefs.getString("dock", "") ?: "", dock)
    }

    private fun parse(s: String, m: HashMap<Int, String>) {
        for (line in s.split("\n")) {
            val p = line.split("\t")
            if (p.size == 2) {
                val cell = p[0].toIntOrNull()
                if (cell != null) m[cell] = p[1]
            }
        }
    }

    private fun ser(m: HashMap<Int, String>): String =
        m.entries.joinToString("\n") { "${it.key}\t${it.value}" }

    private fun saveLayout() {
        prefs.edit().putString("home", ser(home)).putString("dock", ser(dock)).apply()
    }

    private fun saveAndRender() {
        saveLayout()
        render()
    }

    private fun mapFor(from: String): HashMap<Int, String>? = when (from) {
        "home" -> home
        "dock" -> dock
        else -> null
    }

    private fun filter(query: String) {
        val q = query.trim().lowercase()
        val list = if (q.isEmpty()) allApps else allApps.filter { it.label.lowercase().contains(q) }
        drawerAdapter.submit(list)
    }

    // ---------- отрисовка ----------

    private fun render() {
        homeGrid.removeAllViews()
        dockGrid.removeAllViews()
        fill(homeGrid, home, "home")
        fill(dockGrid, dock, "dock")
        hint.visibility = if (home.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun fill(grid: CellGrid, map: HashMap<Int, String>, from: String) {
        for ((cell, key) in map) {
            val app = byKey[key] ?: continue
            if (cell < 0 || cell >= grid.totalCells) continue
            val v = LayoutInflater.from(this).inflate(R.layout.item_app, grid, false)
            (v as LinearLayout).gravity = Gravity.CENTER
            v.findViewById<ImageView>(R.id.icon).setImageDrawable(app.icon)
            v.findViewById<TextView>(R.id.label).text = app.label
            grid.addView(v, CellGrid.Lp(cell))
            attachBehavior(v, app, from, cell)
        }
    }

    // ---------- поведение иконок ----------

    private fun attachBehavior(v: View, app: AppInfo, from: String, cell: Int) {
        var longPressed = false
        var dragging = false
        var downX = 0f
        var downY = 0f

        v.setOnClickListener { launch(app) }
        v.setOnLongClickListener {
            longPressed = true
            it.parent?.requestDisallowInterceptTouchEvent(true)
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            showAppMenu(it, app, from, cell)
            true
        }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    longPressed = false
                    dragging = false
                    downX = e.rawX
                    downY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    if (longPressed) view.parent?.requestDisallowInterceptTouchEvent(true)
                    val dist = hypot(e.rawX - downX, e.rawY - downY)
                    val canDrag = longPressed || (editMode && from != "drawer")
                    if (!dragging && canDrag && dist > touchSlop) {
                        dragging = true
                        longPressed = false
                        dismissMenu()
                        startDrag(view, app, from, cell)
                    }
                }
            }
            false
        }
    }

    private fun startDrag(v: View, app: AppInfo, from: String, cell: Int) {
        val info = DragInfo(app.key, from, cell)
        val clip = ClipData.newPlainText("app", app.key)
        val started = v.startDragAndDrop(clip, View.DragShadowBuilder(v), info, 0)
        if (started) {
            if (from == "drawer") closeDrawer() else v.visibility = View.INVISIBLE
        }
    }

    private fun gridDragListener(grid: CellGrid, map: HashMap<Int, String>) =
        View.OnDragListener { _, e ->
            if (e.action == DragEvent.ACTION_DROP) {
                val info = e.localState as? DragInfo
                if (info != null) place(info, map, grid.cellAt(e.x, e.y))
            }
            true
        }

    private fun zoneListener(onDrop: (DragInfo) -> Unit) = View.OnDragListener { _, e ->
        if (e.action == DragEvent.ACTION_DROP) {
            val info = e.localState as? DragInfo
            if (info != null) onDrop(info)
        }
        true
    }

    private fun removeKey(key: String) {
        home.entries.removeAll { it.value == key }
        dock.entries.removeAll { it.value == key }
    }

    private fun firstFree(map: HashMap<Int, String>, total: Int): Int? =
        (0 until total).firstOrNull { !map.containsKey(it) }

    private fun place(info: DragInfo, dst: HashMap<Int, String>, dstCell: Int) {
        val src = mapFor(info.from)
        if (src === dst && info.fromCell == dstCell) return
        if (src == null) removeKey(info.key) else src.remove(info.fromCell)
        val occupant = dst[dstCell]
        dst[dstCell] = info.key
        if (occupant != null && occupant != info.key) {
            if (src != null) {
                src[info.fromCell] = occupant
            } else {
                val free = firstFree(home, homeGrid.totalCells)
                if (free != null) home[free] = occupant
            }
        }
    }

    private fun addToHome(key: String) {
        removeKey(key)
        val cell = firstFree(home, homeGrid.totalCells)
        if (cell == null) {
            Toast.makeText(this, "На главном экране нет места", Toast.LENGTH_SHORT).show()
            return
        }
        home[cell] = key
        saveAndRender()
        if (drawerOpen) closeDrawer()
    }

    // ---------- меню как в OxygenOS ----------

    private fun dismissMenu() {
        menu?.dismiss()
        menu = null
    }

    private fun showAppMenu(anchor: View, app: AppInfo, from: String, cell: Int) {
        dismissMenu()
        val items = mutableListOf<MenuItem>()
        if (from == "drawer") {
            items.add(MenuItem("На главный экран") { addToHome(app.key) })
        } else {
            items.add(MenuItem("Убрать с экрана") {
                mapFor(from)?.remove(cell)
                saveAndRender()
            })
        }
        items.add(MenuItem("О приложении") {
            try {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                )
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(this, "Не удалось открыть", Toast.LENGTH_SHORT).show()
            }
        })
        if (!app.isSystem) items.add(MenuItem("Удалить") { uninstall(app) })

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = ContextCompat.getDrawable(this, R.drawable.bg_menu)
        box.setPadding(dp(6), dp(6), dp(6), dp(6))
        for (item in items) {
            val tv = TextView(this)
            tv.text = item.title
            tv.setTextColor(ContextCompat.getColor(this, R.color.oxy_text))
            tv.textSize = 15f
            tv.setPadding(dp(18), dp(12), dp(18), dp(12))
            tv.setOnClickListener {
                dismissMenu()
                item.action()
            }
            box.addView(tv)
        }
        box.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val loc = IntArray(2)
        anchor.getLocationOnScreen(loc)
        var x = loc[0] + anchor.width / 2 - box.measuredWidth / 2
        x = maxOf(dp(8), minOf(x, screenW - box.measuredWidth - dp(8)))
        var y = loc[1] + anchor.height
        if (y + box.measuredHeight > screenH - dp(24)) y = loc[1] - box.measuredHeight

        val popup = PopupWindow(box, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false)
        popup.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popup.isOutsideTouchable = true
        popup.elevation = dp(8).toFloat()
        popup.setOnDismissListener { if (menu === popup) menu = null }
        popup.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)
        menu = popup
    }

    private fun uninstall(app: AppInfo) {
        if (app.isSystem) {
            Toast.makeText(this, "Системное приложение нельзя удалить", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}")))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Не удалось удалить", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- режимы ----------

    private fun setEdit(on: Boolean) {
        editMode = on
        editBar.visibility = if (on) View.VISIBLE else View.GONE
    }

    private fun openDrawer() {
        setEdit(false)
        dismissMenu()
        drawerOpen = true
        drawer.visibility = View.VISIBLE
        drawer.translationY = resources.displayMetrics.heightPixels.toFloat()
        drawer.animate().translationY(0f).setDuration(220).start()
    }

    private fun closeDrawer() {
        drawerOpen = false
        drawer.animate()
            .translationY(resources.displayMetrics.heightPixels.toFloat())
            .setDuration(200)
            .withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }
            .start()
        search.setText("")
        search.clearFocus()
        val imm = getSystemService(InputMethodManager::class.java)
        imm?.hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun launch(app: AppInfo) {
        if (editMode) return
        try {
            startActivity(app.launchIntent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Не удалось открыть ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}

class AppAdapter(private val bind: (View, AppInfo) -> Unit) :
    RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppInfo> = emptyList()

    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.icon)
        val label: TextView = view.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return VH(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        bind(holder.itemView, app)
    }
}
