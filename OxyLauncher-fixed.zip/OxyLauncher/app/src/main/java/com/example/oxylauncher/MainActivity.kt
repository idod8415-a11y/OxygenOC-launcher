package com.example.oxylauncher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class AppInfo(
    val label: String,
    val icon: Drawable,
    val launchIntent: Intent
)

class MainActivity : AppCompatActivity() {

    private val allApps = mutableListOf<AppInfo>()
    private lateinit var adapter: AppAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        adapter = AppAdapter { launch(it) }

        findViewById<RecyclerView>(R.id.appGrid).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 4)
            adapter = this@MainActivity.adapter
        }

        findViewById<EditText>(R.id.search).doAfterTextChanged { text ->
            filter(text?.toString().orEmpty())
        }

        loadApps()
        filter("")
    }

    override fun onBackPressed() {
        // Лаунчер — домашний экран, назад ничего не закрывает.
    }

    private fun loadApps() {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(query, 0)

        allApps.clear()
        for (ri in resolved) {
            if (ri.activityInfo.packageName == packageName) continue
            val intent = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            allApps.add(AppInfo(ri.loadLabel(pm).toString(), ri.loadIcon(pm), intent))
        }
        allApps.sortBy { it.label.lowercase() }
    }

    private fun filter(query: String) {
        val q = query.trim().lowercase()
        val list = if (q.isEmpty()) allApps else allApps.filter { it.label.lowercase().contains(q) }
        adapter.submit(list)
    }

    private fun launch(app: AppInfo) {
        try {
            startActivity(app.launchIntent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Не удалось открыть ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }
}

class AppAdapter(private val onClick: (AppInfo) -> Unit) :
    RecyclerView.Adapter<AppAdapter.VH>() {

    private var items: List<AppInfo> = emptyList()

    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.icon)
        val label: TextView = view.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return VH(view)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        holder.icon.setImageDrawable(app.icon)
        holder.label.text = app.label
        holder.itemView.setOnClickListener { onClick(app) }
    }
}
